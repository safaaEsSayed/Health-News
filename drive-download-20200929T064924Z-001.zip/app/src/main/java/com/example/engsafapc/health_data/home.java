package com.example.engsafapc.health_data;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.engsafapc.health_data.Adapters.ResourceAdapter;
import com.example.engsafapc.health_data.Data.Result;
import com.example.engsafapc.health_data.Data.article;
import com.example.engsafapc.health_data.WebAPI.APIService;
import com.example.engsafapc.health_data.WebAPI.RetrofitClient;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class home extends AppCompatActivity {
    ArrayList <article> articles = new ArrayList<>();
    RecyclerView recycler;
    private ResourceAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        recycler=(RecyclerView)findViewById(R.id.recycler) ;
        recycler.setLayoutManager(new LinearLayoutManager (this));
        Resources();


    }

    public  void Resources( ) {



        try {
            APIService apiService = RetrofitClient.retrofitRequest();
            Call <Result> call = apiService.Resoures("health","1b58766a79234156a93711ed508c3184");
            call.enqueue(new Callback <Result> () {
                @Override
                public void onResponse(Call<Result> call, Response <Result> response) {
                    try {
                        if ((response.isSuccessful())) {

                            articles =response.body().getArticles();
                            adapter = new ResourceAdapter(home.this,articles);
                            recycler.setAdapter(adapter);
                        }

                    } catch (Exception ex) {

                    }
                }

                @Override
                public void onFailure(Call<Result> call, Throwable t) {
                    Toast.makeText(home.this,"f",Toast.LENGTH_LONG).show();
                }
            });

        } catch (Exception ex) {
        }
    }


}